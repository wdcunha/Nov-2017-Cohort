This is a base template for **[Lab] Responsive Space**.

