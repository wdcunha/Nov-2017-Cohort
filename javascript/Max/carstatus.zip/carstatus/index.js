// require packages
const express = require('express');

// initialize the app
const app = express();
// tell the app that the view engine you want to use is `ejs`
// (versus jade, or other view engines out there)
// so that we can use .ejs files stored in a `views` folder
// NOTE: all of your views must within a `views` folder and be `.ejs` files
app.set('view engine', 'ejs');

// body-parser is is a middleware
// It allows the browser to send variables to the server
const bodyParser = require('body-parser');
// These lines say: take those variables and add them to a field called `body`
// in the request object
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

// Whenever a GET request is made to the route `/`, run the callback function
app.get('/', function (req, res) {
  // this callback function just renders and sends the `index.ejs`
  // file to the client
  res.render('index');
});

// Whenever a POST request is made to the route `/result`, run the callback
app.post('/result', function(req,res) {
  // This is where we see `body-parser`'s magic in action
  // We can access all of the params that were sent in the post request
  // by accessing the body field of the request object, `req`
  const params = req.body;
  const year = +params.year;
  let age = '';
  switch (true) {
    case (year >= 2018):
      age = 'Future';
      break;
    case (year >= 2014):
      age = 'New';
      break;
    case (year >= 2008):
      age = 'Old';
      break;
    default:
      age = 'Very Old';
      break;
  }
  // res.render takes more parameters than just the name of the view to
  //  send to the client
  // You can also use this to pass variables to the view.
  // in this case, the `age` variable is passed to the `result.ejs` view
  // NOTE: if variable `age` has been defined as 10, {age} === {age: 10}
  // ^ This is just syntactic sugar!!
  res.render('result', {age});
});

const DOMAIN = 'localhost';
const PORT = '4646';
app.listen(PORT, DOMAIN, () => {
  console.log(`🖥 Server listening on http://${DOMAIN}:${PORT}`);
});
