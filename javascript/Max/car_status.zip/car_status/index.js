const express = require('express');
const morgan = require('morgan');
const bodyParser = require('body-parser')


const app = express();

app.set('view engine', 'ejs');

app.use(morgan('dev'))

app.use(bodyParser.urlencoded({exetended: false}));


app.get('/user_input', (request, response) => {
  response.render('userInput');
});

app.post('/user_input', (request, response) => {
  const body = request.body;
  const carYear = body.carYear;

  response.render('response', {carYear: carYear});
});

const DOMAIN = 'localhost';
const PORT = '3002';
app.listen(PORT, DOMAIN, () => {
  console.log(`Server listening on http://${DOMAIN}:${PORT}`);
})
